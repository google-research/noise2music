# V2Meow: Meowing to the Visual Beat via Music Generation
This website accompanies the paper:

[Meowing to the Visual Beat via Music Generation](https://arxiv.org/pdf/2305.06594v1.pdf).
